package com.main.gym_api.model;

public enum EstadoInscripcion {
    INSCRITO,
    CANCELADO,
    COMPLETADO
}
