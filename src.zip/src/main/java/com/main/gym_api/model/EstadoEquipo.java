package com.main.gym_api.model;

public enum EstadoEquipo {
    BUEN_ESTADO,
    MAL_ESTADO,
    FUERA_DE_USO
}
