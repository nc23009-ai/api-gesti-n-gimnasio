package com.main.gym_api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GymApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
